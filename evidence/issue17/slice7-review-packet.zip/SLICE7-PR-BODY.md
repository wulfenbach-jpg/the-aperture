## Issue #17 — partial starter corpus, corrective slice 7

**Draft; full eight-list certification is not complete.** Current corpus: 106 supported real cards; exact eight-list union 459 = 94 supported + 365 missing names. One exact 100-card starter is implemented; zero lists are certified. Arbitrary Archidekt deck compatibility remains a non-goal until proved.

### This corrective increment
- Fix S6-R2-F1: dying Blood Artist/Zulaport watchers are dispatched exactly once for their own death, retaining original battlefield identity across simultaneous-death batches. Fully drained regressions cover single dying watcher, both object orders and surviving watcher control. The independent review224 probe previously failed two assertions; it now passes all three.
- Reconcile the same feature branch with merged master `8de0961` (#16 counters, tokens, keywords and library primitives). A normal merge of master **into the feature branch** preserves all history without the forbidden force push. This does not merge the PR to master.
- Preserve the corpus's real token destination/death event followed by CR111.7 SBA cessation. Reject the initial integration's semantic downgrade; final token objects are removed rather than retained as tombstones. Counter/keyword/visibility APIs remain integrated.
- Fix the remaining contradictory Swords token trace with a genuine RED/GREEN regression: exile occurs first, cessation is not an exile replacement.

### Actually exercised on code head `7e1eb5f1b8218e24d7a03377c3cb3c5bb0981a4f`
- Workspace/all-target tests: 639 passed, zero failed; fmt, warnings-denied workspace Clippy and locked workspace release build pass.
- Unchanged independent review224 probe: 3/3 pass after complete stack/trigger/resolution/pending drainage.
- Real release executable: exact four-seat 40-card `package-slice6-dies` fixture, seed 610, 40 life; terminal P3 after 2952 steps/66 turns, 73 queued triggered abilities/62 resolutions. Separate replay verifies 7239 events and digest `8e0ab4b00e7ff6d018b71ee9317f59c6d794e12472d83bdf4fe2d278c4a3ca8e`.
- All four replay seat snapshots match the requested package file, not bundled replacements; all eight desired starter-list contents remain unchanged.

The game is a **package** exercise, not a desired 100-card starter or Commander certification; no white mana in this package means its Isamaru commanders/Soul Wardens are not cast. Printed card/source provenance remains in existing `fixtures/starter-corpus/slice*-sourced.json` records. No new cards added in this repair.

Exact-head CI on the published head is **10/10 SUCCESS**, including both Windows package jobs; required checks pass. Independent delta adjudication remains pending. Historical request_changes verdicts and RED evidence are preserved. No merge/master push, issue closure, certified downstream unlock, purchases or global provider changes.
